#ifndef SOUND
#define SOUND

void playSound(const char * name);
void killSound(const char * name);

#endif