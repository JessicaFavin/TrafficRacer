#ifndef COLOR_H
#define COLOR_H

char * DEFAULT;
char * BLUE;
char * GREEN;
char * RED;
char * CYAN;
char * YELLOW;
char * BACKROAD;
char * BACKDEFAULT;

char *choixCouleur();

#endif
