#ifndef LIST_CAR_H
#define LIST_CAR_H

void addCar(vehicule * v, vehicule * carList, int nbCars);
void removeCar(vehicule * carList, int nbCars);

#endif
